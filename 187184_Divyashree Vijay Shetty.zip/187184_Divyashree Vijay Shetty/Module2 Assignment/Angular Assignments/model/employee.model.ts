export class Employee {
    id:any;
    name:any;
    sal:any;
    dept:any;

}