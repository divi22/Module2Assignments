import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Lab2part2Component } from './lab2part2.component';

describe('Lab2part2Component', () => {
  let component: Lab2part2Component;
  let fixture: ComponentFixture<Lab2part2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Lab2part2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Lab2part2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
