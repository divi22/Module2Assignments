import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lab3',
  templateUrl: './lab3.component.html',
  styleUrls: ['./lab3.component.css']
})
export class Lab3Component implements OnInit {

  employees = [];
  flag = 0;

  idValid: boolean = false;
  nameValid: boolean=false;
  costValid: boolean=false;
  OnlineProdValid: boolean=false;
  CategoryValid: boolean=false;
  storeValid: boolean=false;
 constructor() { }
  
  ngOnInit() {
  }

  addProd(form) {

    if (!form.id) {
      this.idValid = true;
      return
    }
    else {
      this.idValid = false;
    }

    if (!form.name) {
      this.nameValid = true;
      return
    }
    else {
      this.nameValid = false;
    }

    if (!form.cost) {
      this.costValid = true;
      return
    }
    else {
      this.costValid = false;
    }

    if (!form.POnline) {
      this.OnlineProdValid = true;
      return
    }
    else {
      this.OnlineProdValid = false;
    }

    if (!form.Category) {
      this.CategoryValid = true;
      return
    }
    else {
      this.CategoryValid = false;
    }

    if (!form.store1) {
      this.storeValid = true;
      return
    }
    else {
      this.storeValid = false;
    }
  
    console.log(form);
    this.flag++;
  }
}
