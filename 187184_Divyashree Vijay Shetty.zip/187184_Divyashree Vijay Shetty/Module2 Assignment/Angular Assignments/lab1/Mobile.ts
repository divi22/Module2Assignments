export class Mobile
{
	mobileId:number;
	mobileName:String;
	mobileCost:number;
	public constructor(mobName:String,mobId:number,mobCost:number)
	{
		this.mobileId=mobId;
		this.mobileName=mobName;
		this.mobileCost=mobCost;
	}
	printMobileDetail()
	{
		console.log(this.mobileId);
		console.log(this.mobileName);
		console.log(this.mobileCost);
	}
}
