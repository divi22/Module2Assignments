var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var BasicPhone;
(function (BasicPhone_1) {
    var Mobile = /** @class */ (function () {
        function Mobile(mobName, mobId, mobCost) {
            this.mobileId = mobId;
            this.mobileName = mobName;
            this.mobileCost = mobCost;
        }
        Mobile.prototype.printMobileDetail = function () {
            console.log(this.mobileId);
            console.log(this.mobileName);
            console.log(this.mobileCost);
        };
        return Mobile;
    }());
    BasicPhone_1.Mobile = Mobile;
    var BasicPhone = /** @class */ (function (_super) {
        __extends(BasicPhone, _super);
        function BasicPhone(mobName, mobId, mobCost, mobType) {
            var _this = _super.call(this, mobName, mobId, mobCost) || this;
            _this.mobileType = mobType;
            return _this;
        }
        BasicPhone.prototype.printMobileDetails = function () {
            console.log(this.mobileId);
            console.log(this.mobileName);
            console.log(this.mobileCost);
        };
        return BasicPhone;
    }(Mobile));
    BasicPhone_1.BasicPhone = BasicPhone;
    var e = new BasicPhone('samsung', 1234, 35000, 'smartphone');
    e.printMobileDetail();
})(BasicPhone || (BasicPhone = {}));
