module BasicPhone
{
	export class Mobile
	{
		mobileId:number;
		mobileName:String;
		mobileCost:number;
	    public constructor(mobName:String,mobId:number,mobCost:number)
		{
		this.mobileId=mobId;
		this.mobileName=mobName;
		this.mobileCost=mobCost;
	}
	printMobileDetail()
	{
		console.log(this.mobileId);
		console.log(this.mobileName);
		console.log(this.mobileCost);
	}
}
export class BasicPhone extends Mobile
{
	mobileType:String;
	public constructor(mobName:String,mobId:number,mobCost:number,mobType:String)
	{
		super(mobName,mobId,mobCost);
		this.mobileType=mobType;
	}
	printMobileDetails()
	{
		console.log(this.mobileId);
		console.log(this.mobileName);
		console.log(this.mobileCost);
	}
}
var e=new BasicPhone('samsung',1234,35000,'smartphone');
e.printMobileDetail();
}


