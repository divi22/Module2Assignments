var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var SmartPhone;
(function (SmartPhone_1) {
    var Mobile = /** @class */ (function () {
        function Mobile(mobName, mobId, mobCost) {
            this.mobileId = mobId;
            this.mobileName = mobName;
            this.mobileCost = mobCost;
        }
        Mobile.prototype.printMobileDetail = function () {
            console.log(this.mobileId);
            console.log(this.mobileName);
            console.log(this.mobileCost);
        };
        return Mobile;
    }());
    SmartPhone_1.Mobile = Mobile;
    var SmartPhone = /** @class */ (function (_super) {
        __extends(SmartPhone, _super);
        function SmartPhone(mobName, mobId, mobCost, mobType) {
            var _this = _super.call(this, mobName, mobId, mobCost) || this;
            _this.mobileType = mobType;
            return _this;
        }
        SmartPhone.prototype.printMobileDetail = function () {
            console.log(this.mobileId);
            console.log(this.mobileName);
            console.log(this.mobileCost);
            console.log(this.mobileType);
        };
        return SmartPhone;
    }(Mobile));
    SmartPhone_1.SmartPhone = SmartPhone;
    var e1 = new SmartPhone('samsung', 1234, 35000, 'smartphone');
    e1.printMobileDetail();
})(SmartPhone || (SmartPhone = {}));
