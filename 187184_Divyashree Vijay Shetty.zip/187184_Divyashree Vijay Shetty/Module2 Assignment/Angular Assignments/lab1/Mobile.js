"use strict";
exports.__esModule = true;
var Mobile = /** @class */ (function () {
    function Mobile(mobName, mobId, mobCost) {
        this.mobileId = mobId;
        this.mobileName = mobName;
        this.mobileCost = mobCost;
    }
    Mobile.prototype.printMobileDetail = function () {
        console.log(this.mobileId);
        console.log(this.mobileName);
        console.log(this.mobileCost);
    };
    return Mobile;
}());
exports.Mobile = Mobile;
