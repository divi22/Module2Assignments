package package1;



import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/http")
public class DemoHttpServlet extends HttpServlet
{
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException{
		
	

	  PrintWriter pw=res.getWriter();                                                                                                                                                          
		String userName=req.getParameter("uname");
	
		String passwrd=req.getParameter("passwd");
		
		if(userName.equals("admin") && passwrd.equals("admin")) {
			pw.println("Welcome "+userName);
		}
		else {
			pw.println("Enter valid username and password");
		}
			
	}


	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException{
		
	
	  PrintWriter pw=res.getWriter();
		pw.println("Todays date  from doGet:"+Calendar.getInstance().getTime());
	
		
}
}
