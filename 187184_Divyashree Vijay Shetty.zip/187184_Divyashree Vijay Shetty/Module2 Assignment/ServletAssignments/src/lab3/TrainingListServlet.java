package lab3;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TrainingListServlet
 */
@WebServlet("/list")
public class TrainingListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TrainingListServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Paymentwallet","root","root");
			String sql = "select * from Training";
			PrintWriter pw = response.getWriter();
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()) {
				
//				pw.print(
//						"<html>"
//						+ "<body>"
//						+ "<table>"
//							+ "<tr>"
//								+ "<td>"+ rs.getInt("trainingId") +"</td>"
//								+ "<td>"+ rs.getString("trainingName") +"</td>"
//								+ "<td> "+ rs.getInt("AvailableSeats") + "</td>"
//							+ "</tr>"
//						+ "</table>"
//						+ "</body>"
//						+ "</html>"
//						);
				pw.print("Hello");
			}
		}
		catch(Exception e) {
			System.out.println("Error Occurred while establishing connection");
		}
		finally {
			if(con!=null) {
				try {
					ps.close();
					con.close();
				}
				catch(SQLException e) {
					System.out.println("Your Collection is not properly closed.");
				}
			}
		}

	
	}

}
